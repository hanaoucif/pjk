<!-- traitement_ajout_cours.php -->

<?php
include('Connection.php');


// Récupérer les données du formulaire
$id_ens = $_SESSION['id'];
$titre = $_POST['titre'];
$responsable_cour = $_POST['responsable_cour'];
$public_cible = $_POST['selectOption'];
$cle_inscription = $_POST['cle_inscription'];
$information_sur_le_cour = $_POST['information_sur_le_cour'];

// Insertion des données dans la table Cour
$sql = "INSERT INTO Cour (id, Titre, Responsable_cour, public_cible, clé_d'inscription, information_sur_le_cours)
        VALUES ('$id_ens', '$titre', '$responsable_cour', '$public_cible', '$cle_inscription', '$information_sur_le_cour')";

if ($conn->query($sql) === TRUE) {
    echo "Cours ajouté avec succès.";
} else {
    echo "Erreur lors de l'ajout du cours : " . $conn->error;
}

// Fermer la connexion à la base de données
$conn->close();
?>
