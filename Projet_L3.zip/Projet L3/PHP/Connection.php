<?php


$con= mysqli_connect('localhost','root','','projetl3');

if(!$con){
  die(mysqli_error($con));
 } 
?>