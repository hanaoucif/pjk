<?php
include('Profile_edit_etud_personal.php');
include('Profile_edit_etud_securite.php');

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Edit Profile</title>
  <link rel="stylesheet" href="Edit.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
  <!-- side menu Start -->
  <div class="side-menu">
    <div class="main-content">
      <a href="../Profile page/Profile.php" class="go-back-btn">
        <i class="fa-solid fa-arrow-turn-up"></i>
      </a>

      <div class="side-menu-content">
        <ul>
          <li class="personal-info show">
            <div class="h-line" style="display: none"></div>
            <button id="toglePersonalInfo">Personal info</button>
          </li>
          <li class="appearance">
            <div class="h-line" style="display: none"></div>
            <button id="togleAppearance">Appearance</button>
          </li>
          <li class="security">
            <div class="h-line" style="display: none"></div>
            <button id="togleSecurity">Security</button>
          </li>
        </ul>
      </div>
    </div>
    <button class="log-out-btn"><a href="#">Log out</a></button>
  </div>
  <!-- side menu End -->

  <div class="v-line"></div>

  <!-- main container Start -->
  <div class="main-container">
    <!-- Personal info Start -->
    <div class="personal-info show" style="display: none">
      <form action="Profile_edit_etud_appaarence.php" method="post">
        <div class="triangle-decoration"></div>

        <h1>Personal info</h1>

        <div class="form-content">

          <div>
            <label for="">Nickname</label>
            <input placeholder="Enter nickname here" class="text-input" type="text" name="psuedo" />
          </div>

          <div>
            <label for="">First name</label>
            <input placeholder="Enter first name here" class="text-input" type="text" name="prenom" value="<?php echo $prevprenom; ?>"/>
          </div>

          <div>
            <label for="">Family name</label>
            <input placeholder="Enter family name here" class="text-input" type="text" name="nom" value="<?php echo $prevnom; ?>"/>
          </div>

          <div>
            <label for="">Birth date</label>
            <input class="text-input" type="date" name="bdate" />
          </div>

          <div>
            <label for="">Card number</label>
            <input class="text-input" type="number" disabled value='<?php echo $prevnum_carte; ?>' name="num_carte" />
          </div>

          <div>
            <label for="">Year of study</label>
            <select name="" class="text-input" name="yr-sear-tudy">
              <option value="l1">1st Year of Bachelor's Degree</option>
              <option value="l2">2nd Year of Bachelor's Degree</option>
              <option value="l3">3rd Year of Bachelor's Degree</option>
              <option value="m1">1rd Year of Master's Degree</option>
              <option value="m2">2nd Year of Master's Degree</option>
            </select>
          </div>

        </div>
        <button class="submit-btn" name="personal">Save Changes</button>
      </form>
    </div>
    <!-- Personal info End -->

    <!-- Appearance Start -->
    <div class="appearance" style="display: none">
      <form action="">
        <div class="triangle-decoration"></div>

        <h1>Appearance</h1>

        <div class="form-content">
          <div class="pfp-container">
            <label for="file-input" class="change-pfp">
              Change profile picture
              <input type="file" id="file-input" />
            </label>
            <div class="pfp"></div>
          </div>

          <div class="cover-container">
            <label for="file-input" class="change-cover">
              Change cover photo
              <input type="file" id="file-input" />
            </label>
            <div class="cover"></div>
          </div>
        </div>
        <button class="submit-btn">Save Changes</button>
      </form>
    </div>
    <!-- Appearance End -->

    <!-- Security Start -->
    <div class="security" style="display: none">
      <form action="Profile_edit_ens_securite.php" style="display: flex; flex-direction: column" method="post">
        <div class="triangle-decoration"></div>

        <h1>Security</h1>

        <div class="form-content">
          <div>
            <label for="email">Email</label>
            <input name="email" placeholder="Enter email here" class="text-input" type="email" value="<?php echo $prevemail; ?>"/>
          </div>

          <div>
            <label for="password">Password</label>
            <input name="password" placeholder="Enter password here" class="text-input" type="password" value="<?php echo $prevpassword; ?>"/>
          </div>

          <div>
            <label for="confirm-password">Confirm password</label>
            <input name="confpassword" placeholder="Confirm password here" class="text-input" type="password" value="<?php echo $prevpassword; ?>"/>
          </div>

          <div>
            <label for="phone">Phone number (optional)</label>
            <input name="phone" placeholder="Enter phone number here" class="text-input" type="tel" value=""/>
          </div>
        </div>
        <button class="submit-btn" name="securite">Save Changes</button>
      </form>
    </div>
    <!-- Security End -->
  </div>
  <!-- main container End -->

  <script src="./Edit.js"></script>
</body>

</html>