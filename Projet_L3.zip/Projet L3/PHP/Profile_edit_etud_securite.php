<?php
 
 session_start();
 include('Connection.php');
 if(isset($_POST['securite']))
 {
    $id=$_SESSION['id'];
    $emial=$_POST['email'];
    $password=$_POST['password'];
    $confpassword=$_POST['confpassword'];
    $phone=$_POST['phone'];
    $select= "select * from Etudiant where id='$id'";
    $sql = mysqli_query($conn,$select);
    $row = mysqli_fetch_assoc($sql);
    $res= $row['id'];
    $prevemail= $row['email'];
    $prevpassword= $row['password'];
    //$prevphone=['tel'];
    if($password === $confpassword){
    if($res === $id)
    {
   
       $update = "update Etudiant set email='$email',password='$password' where id='$id'";
       $sql2=mysqli_query($conn,$update);
if($sql2)
       { 
           /*Successful*/
           header('location:TeachView.php');
       }
       else
       {
           /*sorry your profile is not update*/
           header('location:Edit.php');
       }
    }
    else
    {
        /*sorry your id is not match*/
        header('location:Edit.php');
    }
    }else{

    }
 }
?>