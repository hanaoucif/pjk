<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Edit Profile</title>
  <link rel="stylesheet" href="./Edit.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      x
    </style>
</head>

<body>
  <!-- side menu Start -->
  <div class="side-menu">
    <div class="main-content">
      <a href="Profile.php" class="go-back-btn">
        <i class="fa-solid fa-arrow-turn-up"></i>
      </a>

      <div class="side-menu-content">
        <ul>
          <li class="personal-info show">
            <div class="h-line" style="display: none"></div>
            <button id="toglePersonalInfo">Personal info</button>
          </li>
          <li class="appearance">
            <div class="h-line" style="display: none"></div>
            <button id="togleAppearance">Appearance</button>
          </li>
          <li class="security">
            <div class="h-line" style="display: none"></div>
            <button id="togleSecurity">Security</button>
          </li>
        </ul>
      </div>
    </div>
    <button class="log-out-btn"><a href="#">Log out</a></button>
  </div>
  <!-- side menu End -->

  <div class="v-line"></div>

  <!-- main container Start -->
  <div class="main-container">
    <!-- Personal info Start -->
    <div class="personal-info show" style="display: none">
      <form action="profile_edit_ens_personal.php" method="post">
        <div class="triangle-decoration"></div>

        <h1>Personal info</h1>

        <div class="form-content">

          <div>
            <label for="">First name</label>
            <input placeholder="Enter first name here"  class="text-input" type="text" value="<?php echo $prevprenom; ?>"/>
          </div>

          <div>
            <label for="">Family name</label>
            <input placeholder="Enter family name here" class="text-input" type="text" value="<?php echo $prevnom; ?>" />
          </div>

          <div>
            <label for="">Birth date</label>
            <input class="text-input" type="date"  />
          </div>

          <div>
            <label for="">Rank</label>
            <select name="rank" class="text-input">
              <option value="professor">Professor</option>
              <option value="assistantP">Assistant professor</option>
              <option value="lecturer-A">Lecturer A</option>
              <option value="lecturer-B">Lecturer B</option>
              <option value="seniorL-A">Senior Lecturer A</option>
              <option value="seniorL-B">Senior Lecturer B</option>
              <option value="phdS">Ph.D. student</option>
            </select>
          </div>

          <div>
            <label for="">Field</label>
            <select name="field" class="text-input">
              <option value="cs">Computer Science</option>
              <!-- other options depending on the data base -->
            </select>
          </div>
        </div>
        <button class="submit-btn" name="personal">Save Changes</button>
      </form>
    </div>
    <!-- Personal info End -->

    <!-- Appearance Start -->
    <div class="appearance" style="display: none">
      <form action="">
        <div class="triangle-decoration"></div>

        <h1>Appearance</h1>

        <div class="form-content">
          <div class="pfp-container">
            <label for="file-input" class="change-pfp">
              Change profile picture
              <input type="file" id="file-input" />
            </label>
            <div class="pfp"></div>
          </div>

          <div class="cover-container">
            <label for="file-input" class="change-cover">
              Change cover photo
              <input type="file" id="file-input" />
            </label>
            <div class="cover"></div>
          </div>
        </div>
        <button class="submit-btn">Save Changes</button>
      </form>
    </div>
    <!-- Appearance End -->

    <!-- Security Start -->
    <div class="security" style="display: none">
      <form action="Profile_edit_ens_securite.php" style="display: flex; flex-direction: column" method="post">
        <div class="triangle-decoration"></div>

        <h1>Security</h1>

        <div class="form-content">
          <div>
            <label for="email">Email</label>
            <input name="email" placeholder="Enter email here" class="text-input" type="email" value="<?php echo $prevemail; ?>"/>
          </div>

          <div>
            <label for="password">Password</label>
            <input name="password" placeholder="Enter password here" class="text-input" type="password" value="<?php echo $prevpassword; ?>" />
          </div>

          <div>
            <label for="confpassword">Confirm password</label>
            <input name="confpassword" placeholder="Confirm password here" class="text-input" type="password" value="<?php echo $prevpassword; ?>"/>
          </div>

          <div>
            <label for="phone">Phone number (optional)</label>
            <input name="phone" placeholder="Enter phone number here" class="text-input" type="tel" value="" />
          </div>
        </div>
        <button class="submit-btn" name="securite">Save Changes</button>
      </form>
    </div>
    <!-- Security End -->
  </div>
  <!-- main container End -->

  <script src="Edit.js"></script>
</body>

</html>