// Function to change the background color of the navbar on scroll
function handleScroll() {
  const navbar = document.querySelector("#old-menu");
  const scrollY = window.scrollY;

  // You can set a threshold value for when the background color changes
  // For example, change color when scrolled down by 100 pixels
  if (scrollY >= 25) {
    navbar.style.backgroundColor = "white";
    // navbar.style.boxShadow = "0 0 10px rgba(0, 0, 0, 0.2)";
    navbar.style.boxShadow = "0 0 10px rgba(255, 255, 255, 1)";

    //for transition nav
    navbar.style.transition = "background-color 0.5s ease-in-out";
  } else {
    navbar.style.backgroundColor = "transparent";
  }
}

window.addEventListener("scroll", handleScroll);

// This to make the sous-menu
function toggleSubMenu(departmentId) {
  var submenu = document.getElementById(departmentId);
  if (submenu.style.display === "none" || submenu.style.display === "") {
    submenu.style.display = "block";
  } else {
    submenu.style.display = "none";
  }
}
