
<?php


$con= mysqli_connect('localhost','root','','projetl3');

if(!$con){
  die(mysqli_error($con));
 } 





$use=0;
$seccess=0;

if(isset($_POST['logP'])){
   
  
  if (isset($_POST['Type'])){
  $nom1=$_POST['nom1'];
  $nom2=$_POST['nom2'];
  $email=$_POST['email'];
  $pass=$_POST['pass'];

 
 if($_POST['Type']==="Teacher"){
    $grade=$_POST['Grade'];
    $domaine=$_POST['Domaine'];
    $sqli="SELECT * FROM enseignant where prenom='$nom1' and nom='$nom2'";

  }else{
    $sqli="SELECT * FROM etudiant where prenom='$nom1' and nom='$nom2'";
    
  }
  
  $res=mysqli_query($con,$sqli);
  
  if($res){
  $ex=mysqli_num_rows($res);
  if($ex>0){
    //user already exist
    $use=1;
  }else{
    if($_POST['Type']=="Teacher"){
      $sql="INSERT INTO enseignant ( nom,prenom ,email, password ,Grade,domaine) 
      VALUES ('$nom2','$nom1','$email','$pass','$grade','$domaine')";

    }
    else{
    $sql="INSERT INTO etudiant ( nom,prenom ,email, password) 
VALUES ('$nom2','$nom1','$email','$pass')";

    }
$res=mysqli_query($con,$sql);
if($res){
  //signup seccessful
  $seccess=1;
  //header('location:login.php');
} else{
  die(mysqli_error($con));
}
}
}
}
}
?>







 
<?php
$con= mysqli_connect('localhost','root','','projetl3');

if(!$con){
  die(mysqli_error($con));
 } 

$invalid=0;
$logg=0;
if(isset($_POST['log'])){
   
$nom=$_POST['user'];
$pass=$_POST['pass'];

$sqli="SELECT * FROM etudiant where email='$nom' and password='$pass'";
$sql="SELECT * FROM enseignant where email='$nom' and password='$pass'";
$resE=mysqli_query($con,$sqli);
$resP=mysqli_query($con,$sql);
 if($resE){
   $ex=mysqli_num_rows($resE);
   if($ex>0){
      $logg=1;
       session_start();
      $_SESSION['userE']=$nom;
      header('location:loading.php');
   }else{
      $invalid=1;
 }
 }

 if($resP){
  $ex=mysqli_num_rows($resP);
  if($ex>0){
     $logg=1;
     session_start();
     $_SESSION['userP']=$nom;
     header('location:loading.php');
  }else{
     $invalid=1;
}
}
if($nom==="admin" && $pass==="admin12345"){
  session_start();
  $_SESSION['useradmin']=$nom;
  header('location:adminhome.php');
}
}
?>

































<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="./CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.rtl.min.css" integrity="sha384-PRrgQVJ8NNHGieOA1grGdCTIt4h21CzJs6SnWH4YMQ6G5F5+IEzOHz67L4SQaF0o" crossorigin="anonymous">

    <title>EduCS | LogIn</title>
</head>
<body>


<?php
if($use){
     echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
     <strong>ohh no sorry!</strong> user already exist
     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div> ';
    }
    if($seccess){
      echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>success</strong> user is signed up
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div> ';
   }
   ?>
<?php
if($logg){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>success</strong> you are successfuly logged in
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div> ';
   }

   if($invalid){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>error</strong> invalid credentials
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div> ';
   }
   ?>
















    <a href="TO-Home-Page" id="LogoBtn" style="text-decoration: none; font-size: 35px; font-weight: 500;">
        <span class="Logo">Edu
            <span class="logoCS">CS</span>
        </span>
    </a>
    <div class="container" id="container">
        <div class="form-container sign-up">
            <form method="post" action="login2.php">
                <h1 style="margin-bottom: 15px;">Create Account</h1> 
                <!--<span>use your email for registeration</span>-->
                <input type="text" placeholder="First Name" name="nom1">
                <input type="text" placeholder="Familly Name" name="nom2">
                <input type="email" placeholder="Email" name="email">
                <input type="password" placeholder="Password" name="pass">
                <div class="radio">
                    <input type="radio" id="student" name="Type" value="Student">
                    <label for="student">Student</label>
                    <input type="radio" id="teacher-radio" name="Type" value="Teacher">
                    <label for="teacher-radio">Teacher</label>
                </div>
                <select name="Domaine" id="domain">
                    <option value="Informatic">Informatic</option>
                    <option value="Maths">Maths</option>
                    <option value="Physics">Physics</option>
                    <option value="English Language">English Language</option>
                    <option value="French Language">French Language</option>
                </select>
                <select name="Grade" id="grade">
                    <option value="Maître Assistant Classe «B»">Maître Assistant Classe «B»</option>
                    <option value="Maître Assistant Classe «A»">Maître Assistant Classe «A»</option>
                    <option value="Maître de Conférences Classe «A»">Maître de Conférences Classe «A»</option>
                    <option value="Maître de Conférences Classe «B»">Maître de Conférences Classe «B»</option>
                    <option value="Professeur">Professeur</option>
                </select>

                <button type="submit" name="logP">Sign Up</button>
            </form>
        </div>

        <div class="form-container sign-in">
            <form method="post" action="login2.php">
                <h1>Sign In</h1>
                <span>or use your email & password</span>
                <input type="text" placeholder="Email" name="user" >
                <input type="password" placeholder="Password" name="pass">
                <button name="log" type="submit">Sign In</button>
              
            </form>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Welcome Back!</h1>
                    <p>Enter your personal details to use all of features</p>
                    <button class="hidden" id="login">Sign In</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>Hello, Friend!</h1>
                    <p>Register with your personal details to use all of features</p>
                    <button class="hidden" id="register" href="tologin.html">Sign Up</button>
                </div>
            </div>
        </div>
    </div>

    <script src="./JS/script1.js"></script> 
</body>
</html>