// Page swaping
const toglePersonalInfoBtn = document.querySelector("#toglePersonalInfo");
const togleAppearanceBtn = document.querySelector("#togleAppearance");
const togleSecurityBtn = document.querySelector("#togleSecurity");

const personalInfo = document.querySelectorAll(".personal-info");
const appearance = document.querySelectorAll(".appearance");
const security = document.querySelectorAll(".security");

toglePersonalInfoBtn.addEventListener("click", () => {
  personalInfo[0].classList.add("show");
  personalInfo[1].classList.add("show");

  appearance[0].classList.remove("show");
  appearance[1].classList.remove("show");

  security[0].classList.remove("show");
  security[1].classList.remove("show");
});

togleAppearanceBtn.addEventListener("click", () => {
  personalInfo[0].classList.remove("show");
  personalInfo[1].classList.remove("show");

  appearance[0].classList.add("show");
  appearance[1].classList.add("show");

  security[0].classList.remove("show");
  security[1].classList.remove("show");
});

togleSecurityBtn.addEventListener("click", () => {
  personalInfo[0].classList.remove("show");
  personalInfo[1].classList.remove("show");

  appearance[0].classList.remove("show");
  appearance[1].classList.remove("show");

  security[0].classList.add("show");
  security[1].classList.add("show");
});
