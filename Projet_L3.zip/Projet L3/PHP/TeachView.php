<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style/TeachView.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      crossorigin="anonymous"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700&family=Oswald:wght@200;300;400;500;600;700&family=Rubik:ital,wght@0,300;0,400;0,700;1,300;1,500&display=swap"
      rel="stylesheet"
    />
    <title>Document</title>
  </head>
  <body>
    <header>
      <div class="links">
        <a href="">Accuil</a>
        <a href="">Tableau De Bord</a>
        <a href="">Mes Cours</a>
      </div>
      <img src="picture/icon-user.svg" alt="ALT" />
    </header>

    <section class="one">
      <h1>Mes Cours</h1>
      <div class="inputs">
        <input type="text" placeholder="Rechercher" />
        <br />
        <select name="" id="">
          <option value="">Trier Par Nom</option>
          <option value="">Trier Par Date</option>
        </select>
      </div>

      <div class="cours">
        <div class="card">
          <img src="picture/3974104 1.svg" alt="Alt" />
          <div class="content">
            <h1 class="titleCard">title</h1>
            <p class="special">Level :</p>
          </div>
        </div>
        <div class="card">
          <img src="picture/3974104 1.svg" alt="Alt" />
          <div class="content">
            <h1 class="titleCard">title</h1>
            <p class="special">Level :</p>
          </div>
        </div>
        <?php
  $con= mysqli_connect('localhost','root','','projetl3');

  if(!$con){
    die(mysqli_error($con));
   } 


   getcoursM();


 
        ?>



               </div>
            </div>
            <?php
function getcoursM(){
 
  global $con;

     $stor = $_SESSION['userE'];

     $sql3 ="SELECT * FROM etudiant";
                   $res3=mysqli_query($con,$sql3);


               while($row3 =mysqli_fetch_assoc($res3)){
                 $etudiant_email=$row3['email'];

                 if($stor===$etudiant_email){
                   $idM=$row3['id'];

                 }
               }
 echo $idM;
                $sql = "SELECT * FROM cours WHERE id='$idM' ";
      $res=mysqli_query($con,$sql);


      $ss ="SELECT * FROM enseignant";


      $res2=mysqli_query($con,$ss);
   while($row =mysqli_fetch_assoc($res)){
     $cour_id=$row['id'];
     $public_cible=$row['public-cible'];
  while($row2 =mysqli_fetch_assoc($res2)){
    $idd=$row2['id'];

    if( $cour_id===$idd){
      $teacher_nom=$row2['nom'];
      $teacher_prenom=$row2['prénom'];

    }
  }




     $cour_title=$row['Titre'];
     $cour_desc=$row['Information-sur-le-cours'];


     echo '
     <div class="card">
        <img src="picture/3974104 1.svg" alt="Alt" />
        <div class="content">
          <h1 class="titleCard">Title: ' . $cour_title . '</h1>
          <p class="special">Level: ' . $public_cible . '</p>
        </div>
     </div>';


   }
  } 
  ?>
      </div>
    </section>

    <section class="secTwo">
      <h1 class="add" onclick="toggleForm()">Add New Course</h1>

      <form id="courseForm" action="/backend-endpoint" method="post">

        <label for="courseName">Course Name:</label>
        <input type="text" id="courseName" name="courseName" required />
        <br />


        <label for="courseDescription">Course Description:</label>
        <textarea
          id="courseDescription"
          name="courseDescription"
          rows="4"
          required
        ></textarea>
        <br />

        <label for="materialInput">Choose a file:</label>
        <input type="file" id="resourceFile" name="resourceFile" accept="application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
        <br />

        <input type="submit" value="Add Course" />
      </form>
    </section>
    <script>
      function toggleForm() {
        var form = document.getElementById("courseForm");
        form.style.display =
          form.style.display === "none" || form.style.display === ""
            ? "block"
            : "none";
      }
    </script>
  </body>
</html>
