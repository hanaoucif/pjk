<?php




$con= mysqli_connect('localhost','root','','projetl3');

if(!$con){
  die(mysqli_error($con));
 } 


function getcours(){

global $con;
    $sql ="SELECT * FROM cour";
    $res=mysqli_query($con,$sql);

 
    $ss ="SELECT * FROM enseignant";
    
    
    $res2=mysqli_query($con,$ss);
 while($row =mysqli_fetch_assoc($res)){
   $cour_id=$row['id_cour'];



while($row2 =mysqli_fetch_assoc($res2)){
  $idd=$row2['id_ens'];
  
  if( $cour_id===$idd){
    $teacher_nom=$row2['nom'];
    $teacher_prenom=$row2['prenom'];

  }
}




   $cour_title=$row['titre'];
   $cour_desc=$row['information_sur_le_cour'];
   
  
 echo "
 
 <div class='card'>
 <img src='./images/3974104 1.svg ' alt='Alt' />
 <div class='content'>
   <h1 class='titleCard'>$cour_title</h1>
   <p>
   $cour_desc
   </p>
   <p class='special'>Teacher :   $teacher_nom . . $teacher_prenom</p>
  
   <button>Get Started</button>
 </div>
 
 
 
 
 </div>
 
 
 
 ";
 
 
 }
}

function getteacher(){

  global $con;
      $sql ="SELECT * FROM enseignant";
      $res=mysqli_query($con,$sql);

   
   while($row =mysqli_fetch_assoc($res)){
     $teacher_id=$row['id_ens'];
     $teacher_nom1=$row['nom'];
     $teacher_nom2=$row['prenom'];
     $email=$row['email'];
     $grade=$row['grade'];
     $domaine =$row['domaine'];

   echo "
   <div class='container'>
   <div class='banner-img'></div>
   <img src='./images/user m.png' alt='profile image' class='profile-img'>
   <h1 class='name'>$teacher_nom1  $teacher_nom2 </h1>
   <p>$email</p>
   <p>$grade</p>
   <p>$domaine</p>
   
 </div>
  
   
   
   
   ";
   
   
   }
  }






// Searching courses

function search_courses(){
    global $con;
    if(isset($_GET['search_data_cours'])){
        $search_data_value=$_GET['search_data'];
    $search_sql="SELECT * FROM cour where keywords like '%$search_data_value%'";
    $res=mysqli_query($con,$search_sql);
 //$row =mysqli_fetch_assoc($res);
 $ss ="SELECT * FROM enseignant";
    
    
    $res2=mysqli_query($con,$ss);
 while($row =mysqli_fetch_assoc($res)){
   $cour_id=$row['id_cour'];



while($row2 =mysqli_fetch_assoc($res2)){
  $idd=$row2['id_ens'];
  
  if( $cour_id===$idd){
    $teacher_nom=$row2['nom'];
    $teacher_prenom=$row2['prenom'];

  }
}




   $cour_title=$row['titre'];
   $cour_desc=$row['information_sur_le_cour'];
   
  
 echo "
 
 <div class='card'>
 <img src='./images/3974104 1.svg ' alt='Alt' />
 <div class='content'>
   <h1 class='titleCard'>$cour_title</h1>
   <p>
   $cour_desc
   </p>
   <p class='special'>Teacher :   $teacher_nom . . $teacher_prenom</p>
  
   <button>Get Started</button>
 </div>
 
 
 
 
 </div>
 
 
 
 ";
 
 
 }
}
}
// Searching teachers


function searchingteacher(){

  global $con;
     
      if(isset($_GET['search_data_teacher'])){
        $search_data_value=$_GET['search'];
    $search_sql="SELECT * FROM enseignant where keywords like '%$search_data_value%'";
    $res=mysqli_query($con,$search_sql);
  
   
   while($row =mysqli_fetch_assoc($res)){
     $teacher_id=$row['id_ens'];
     $teacher_nom=$row['nom'];
    $email =$row['email'];
   echo "
   <div class='container'>
   <div class='banner-img'></div>
   <img src='./images/user m.png' alt='profile image' class='profile-img'>
   <h1 class='name'>$teacher_nom</h1>
   <p class='description'>Hi there! My name is $teacher_nom  .</p>
   <p class='description'> My email is $email  .</p>
   <button class='btn'>Follow</button>
 </div>
  
   
   
   
   ";
   
   
   }
  }



}









// function getcoursM(){
 
//   global $con;
  
//      $stor = $_SESSION['userE'];

//      $sql3 ="SELECT * FROM etudiant";
//                    $res3=mysqli_query($con,$sql3);
              
               
//                while($row3 =mysqli_fetch_assoc($res3)){
//                  $etudiant_email=$row3['email'];
                 
//                  if($stor===$etudiant_email){
//                    $idM=$row3['id_etud'];
                   
//                  }
//                }
//  echo $idM;
//                 $sql = "SELECT * FROM cour WHERE id_etud='$idM' ";
//       $res=mysqli_query($con,$sql);
  
   
//       $ss ="SELECT * FROM enseignant";
      
      
//       $res2=mysqli_query($con,$ss);
//    while($row =mysqli_fetch_assoc($res)){
//      $cour_id=$row['id_cour'];
//   while($row2 =mysqli_fetch_assoc($res2)){
//     $idd=$row2['id_ens'];
    
//     if( $cour_id===$idd){
//       $teacher_nom=$row2['nom'];
//       $teacher_prenom=$row2['prenom'];
  
//     }
//   }
  
  
  
  
//      $cour_title=$row['titre'];
//      $cour_desc=$row['information_sur_le_cour'];
     
    
//    echo "
   
//    <div class='card'>
//    <img src='./images/3974104 1.svg ' alt='Alt' />
//    <div class='content'>
//      <h1 class='titleCard'>$cour_title</h1>
//      <p>
//      $cour_desc
//      </p>
//      <p class='special'>Teacher :   $teacher_nom . . $teacher_prenom</p>
    
//      <button>Get Started</button>
//    </div>
   
   
   
   
//    </div>
   
   
   
//    ";
   
   
//    }
//   }


function getcoursM(){
  global $con;

  // Récupérer l'email de l'étudiant à partir de la session
  $stor = $_SESSION['userE'];

  $sql3 = "SELECT * FROM etudiant WHERE email='$stor'";
  $res3 = mysqli_query($con, $sql3);

  // Vérifier si l'étudiant existe
  if (mysqli_num_rows($res3) > 0) {
      $row3 = mysqli_fetch_assoc($res3);
      $idM = $row3['id_etud'];

      // Sélectionner les cours de l'étudiant à partir de la table d'inscription
      $sql = "SELECT * FROM inscription_cour_etud WHERE id_etud='$idM'";
      $res = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_assoc($res)) {
          $id_courI = $row['id_cour'];

          // Sélectionner les détails du cours à partir de la table de cours
          $sql1 = "SELECT * FROM cour WHERE id_cour='$id_courI'";
          $res1 = mysqli_query($con, $sql1);

          if ($row1 = mysqli_fetch_assoc($res1)) {
              $cour_title = $row1['titre'];
              $cour_desc = $row1['information_sur_le_cour'];
              $teacher_nom = $row1['responsable_cour'];

              // Afficher les détails du cours dans une carte
              echo "
                  <div class='card'>
                      <img src='./images/3974104 1.svg ' alt='Alt' />
                      <div class='content'>
                          <h1 class='titleCard'>$cour_title</h1>
                          <p>$cour_desc</p>
                          <p class='special'>Teacher: $teacher_nom </p>
                          <button>Get Started</button>
                      </div>
                  </div>
              ";
          }
      }
  } else {
      // Gérer le cas où l'étudiant n'est pas trouvé
      echo "Student not found.";
  }
}

    







 ?>