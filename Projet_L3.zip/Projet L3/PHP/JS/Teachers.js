//to top function
let mybutton = document.getElementById("myBtn");
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0; 
  document.documentElement.scrollTop = 0;
}
/*jdid*/
// Function to change the background color of the navbar on scroll 
function handleScroll() {
  const navbar = document.querySelector('#old-menu');
  const scrollY = window.scrollY;

  // You can set a threshold value for when the background color changes
  // For example, change color when scrolled down by 100 pixels
  if (scrollY >= 100) {
      navbar.style.backgroundColor = 'white';
      navbar.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.2)';

    
      //for transition nav
      navbar.style.transition= 'background-color 0.5s ease-in-out';
    
  
  } else {
      navbar.style.backgroundColor = 'transparent';
  
  }
}
/*hide nav bar while scrolling*/
window.onscroll=function(){
  var pos=window.pageYOffset;
  if(pos>50){
document.getElementById("old-menu").style.top='-100px';
  }else{
document.getElementById("old-menu").style.top='0';
  }
}