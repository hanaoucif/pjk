<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="./CSS/style.css">
    <title>Chat - Dr flen</title>
    <!-- title dynamic -->
</head>
<body class="chat-container">
    <header class="chat-header">
        <a href="teachers.php" id="return"><i class="fa-solid fa-angle-left"></i></a>
        <h3><i class="fa fa-user me-2" id="icon"></i>Dr Flen<!--Dynamic--></h3>
    </header>
    <div class="type-box">
        <form method="post">
            <!--<i class="fa-solid fa-plus" id="uploadBtn"></i>-->
            <!--<input type="file">-->
            <input type="text" id="message-box" placeholder="Type your messages Here...">
            <button type="submit"><i class="fa-solid fa-paper-plane fa-2x"></i></button>
        </form>
    </div>
</body>
</html>