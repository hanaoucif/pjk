<?php
include('functions.php');

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/teachers.css">
    <script src="/Teachers.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700&family=Oswald:wght@200;300;400;500;600;700&family=Rubik:ital,wght@0,300;0,400;0,700;1,300;1,500&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Teachers</title>
</head>
<body>
  <!--nav-->
  <header>
    <div id="old-menu">
      <div id="menu">
        <nav>
          <div id="logo">
            <img style="border-radius: 50%;" width="150px" src="./images/logo.png" alt="ALT">
          </div>
          <ul class = "navList">
            <a href="home.php">
              <li>Home</li>
            </a>
            <a href="home.php">
              <li>About</li>
            </a>
            <a href="teachers.php">
              <li>Teachers </li>
            </a>
            <a href="courses.php">
              <li>Courses </li>
            </a>
            <a href="#">
              <li>Guides </li>
            </a>
          </ul>

          <div class="searchBox">

            <input class="searchInput" type="text" name="" placeholder="Search something">
            <button class="searchButton" href="#">



              <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29" fill="none">
                <g clip-path="url(#clip0_2_17)">
                  <g filter="url(#filter0_d_2_17)">
                    <path
                      d="M23.7953 23.9182L19.0585 19.1814M19.0585 19.1814C19.8188 18.4211 20.4219 17.5185 20.8333 16.5251C21.2448 15.5318 21.4566 14.4671 21.4566 13.3919C21.4566 12.3167 21.2448 11.252 20.8333 10.2587C20.4219 9.2653 19.8188 8.36271 19.0585 7.60242C18.2982 6.84214 17.3956 6.23905 16.4022 5.82759C15.4089 5.41612 14.3442 5.20435 13.269 5.20435C12.1938 5.20435 11.1291 5.41612 10.1358 5.82759C9.1424 6.23905 8.23981 6.84214 7.47953 7.60242C5.94407 9.13789 5.08145 11.2204 5.08145 13.3919C5.08145 15.5634 5.94407 17.6459 7.47953 19.1814C9.01499 20.7168 11.0975 21.5794 13.269 21.5794C15.4405 21.5794 17.523 20.7168 19.0585 19.1814Z"
                      stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                      shape-rendering="crispEdges"></path>
                  </g>
                </g>
                <defs>
                  <filter id="filter0_d_2_17" x="-0.418549" y="3.70435" width="29.7139" height="29.7139"
                    filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                      result="hardAlpha"></feColorMatrix>
                    <feOffset dy="4"></feOffset>
                    <feGaussianBlur stdDeviation="2"></feGaussianBlur>
                    <feComposite in2="hardAlpha" operator="out"></feComposite>
                    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"></feColorMatrix>
                    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_17"></feBlend>
                    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_17" result="shape"></feBlend>
                  </filter>
                  <clipPath id="clip0_2_17">
                    <rect width="28.0702" height="28.0702" fill="white" transform="translate(0.403503 0.526367)">
                    </rect>
                  </clipPath>
                </defs>
              </svg>


            </button>
          </div>

          <button class="pushable">
            <span class="shadow"></span>
            <span class="edge"></span>
            <span class="front">
              Sign in
            </span>
          </button>


          </ul>
        </nav>

      </div>
    </div>
  </header>
  
    <!---/nav-->
    <div class="title">Teachers</div>
        <div class="contain">
        
        <div class="dropdown">
            <button class="dropbtn">Filter</button>
            <div class="dropdown-content">
              <a href="#">Link 1</a>
              <a href="#">Link 2</a>
              <a href="#">Link 3</a>
            </div>
          </div>
          <!--search bar-->
          <div class="search">
            <form action="#" method="get">
                <input type="text"
                       placeholder=" Search Courses..."
                       name="search">
                <button name="search_data_teacher">
                    <i class="fa fa-search"
                       style="font-size:30px;">
                    </i>
                </button>
            </form>
        </div>
    
          <!--end search bar-->
          
          <div class="dropdown">
            <button class="dropbtn">Sort by</button>
            <div class="dropdown-content">
              <a href="#">Link 1</a>
              <a href="#">Link 2</a>
              <a href="#">Link 3</a>
            </div>
          </div>
        </div>
<!--teachers-->



    <div class="wrapper-grid">
      
    <?php
  $con= mysqli_connect('localhost','root','','projetl3');

  if(!$con){
    die(mysqli_error($con));
   } 


   searchingteacher();


 
        ?>
     
      </div>
      <!-- Start Footer  -->
      <footer class="footer-distributed">
        <div class="footer-left">
          <a href="#" style="text-decoration: none"
            ><h3>Edu<span>Cs</span></h3></a
          >
  
          <p class="footer-links">
            <a href="home.html" class="link-1">Home</a>
  
            <a href="Courses.html">courses</a>
            <a href="home.html">About Us</a>
            <a href="contact.html">Contact</a>
          </p>
  
          <p class="footer-company-name">Edu cs ©2023.All Right Reserved</p>
        </div>
  
        <div class="footer-center">
          <div>
            <i class="fa fa-map-marker"></i>
            <p><span>univ blida</span>soumaa</p>
          </div>
  
          <div>
            <i class="fa fa-phone"></i>
            <p>+21325656566</p>
          </div>
          <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:support@company.com">educs@univ-blida.com</a></p>
          </div>
        </div>
  
        <div class="footer-right">
          <p class="footer-company-about">
            <span>About Ed cs</span>
            E-learning platforme.
          </p>
  
          <div class="footer-icons">
            <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
            <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
          </div>
        </div>
      </footer>
        <script src="./JS/Teachers.js"></script>
      
  </body>


</html>