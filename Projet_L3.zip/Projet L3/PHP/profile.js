// Page swaping
const togleCoursesBtn = document.querySelector("#togleCourses");
const togleCommentsBtn = document.querySelector("#togleComments");

const courses = document.querySelectorAll(".courses");
const comments = document.querySelectorAll(".comments");

togleCoursesBtn.addEventListener("click", () => {
  courses[0].classList.add("show-crs-cmt");
  courses[1].classList.add("show-crs-cmt");
  comments[0].classList.remove("show-crs-cmt");
  comments[1].classList.remove("show-crs-cmt");
});
togleCommentsBtn.addEventListener("click", () => {
  comments[0].classList.add("show-crs-cmt");
  comments[1].classList.add("show-crs-cmt");
  courses[0].classList.remove("show-crs-cmt");
  courses[1].classList.remove("show-crs-cmt");
});

// Showing long messages
let fullCommentsArray = [];
const commentsContent = document.querySelectorAll(".comment-content");
const commentBtn = document.querySelectorAll(".show-more-comment-btn");

for (let i = 0; i < commentsContent.length; i++) {
  if (commentsContent[i].innerHTML.length > 134) {
    var fullComment = commentsContent[i].innerHTML;
    fullCommentsArray.push(fullComment);
    commentsContent[i].innerHTML =
      commentsContent[i].innerHTML.substring(0, 119) + " ...";

    commentBtn[i].classList.add("long-text");
  } else fullCommentsArray.push("");
}

for (let i = 0; i < commentBtn.length; i++) {
  commentBtn[i].addEventListener("click", () => {
    commentsContent[i].innerHTML = fullCommentsArray[i];
    commentBtn[i].classList.remove("long-text");
    commentsContent[i].classList.add("card-content-long-text");
  });
}
