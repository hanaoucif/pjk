<!-- ajouter_cours.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un cours</title>
    <style>/* Ajoutez ces styles dans le bloc <style> de votre page HTML ou dans un fichier CSS externe */

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 8px;
}

input[type="text"],
textarea,
select {
    width: 100%;
    padding: 8px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}

select {
    width: calc(100% - 16px); /* Compensate for the padding */
}

input[type="submit"] {
    background-color: #4caf50;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #45a049;
}
</style>
</head>
<body>

<form action="traitement_ajout_cours.php" method="post">
    <!-- Les champs du formulaire -->
    <label for="titre">Titre :</label>
    <input type="text" id="titre" name="titre" required><br>

    <label for="responsable_cour">Responsable du cours :</label>
    <input type="text" id="responsable_cour" name="responsable_cour" required><br>

    <label for="public_cible">Public cible :</label>
    <select id="selectOption" name="selectOption">
        <option value="L1">L1</option>
        <option value="L2">L2</option>
        <option value="L3">L3</option>
        <option value="M1">M1</option>
        <option value="M2">M2</option>
    </select><br>

    <label for="cle_inscription">Clé d'inscription :</label>
    <input type="text" id="cle_inscription" name="cle_inscription" required><br>

    <label for="information_sur_le_cour">Informations sur le cours :</label>
    <textarea id="information_sur_le_cour" name="information_sur_le_cour" required></textarea><br>

    <!-- Champ caché pour passer l'id_ens -->
    <input type="hidden" name="id_ens" value="<?php echo $id_ens; ?>">

    <!-- Bouton de soumission -->
    <input type="submit" value="Ajouter le cours">
</form>

</body>
</html>

