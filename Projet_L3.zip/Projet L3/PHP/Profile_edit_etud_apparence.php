<?php
 
 session_start();
 include('Connection.php');
 if(isset($_POST['personal']))
 {
    $id=$_SESSION['id'];

    $prenom=$_POST['prénom'];
    $nom=$_POST['nom'];
    $bdate=$_POST['bdate'];
    $year_of_study['yr-sear-tudy'];
    $select= "select * from etudiant where id='$id'";
    $sql = mysqli_query($conn,$select);
    $row = mysqli_fetch_assoc($sql);
    $_SESSION['prevnom']=$row['prénom'];
    $_SESSION['nom']=$row['nom'];
    
    $res= $row['id'];
    $prevprenom=$row['prénom'];
    $prevnom=$row['nom'];
    $prevnum_carte=$row['numéro-de-la-carte'];
    if($res === $id)
    {
   
       $update = "update etudiant set prénom='$prenom',nom='$nom',L'année='$year_of_study' where id='$id'";
      
       $sql2=mysqli_query($conn,$update);
if($sql2)
       { 
           /*Successful*/
           header('location:TeachView.php');
       }
       else
       {
           /*sorry your profile is not update*/
           header('location:Edit.php');
       }
    }
    else
    {
        /*sorry your id is not match*/
        header('location:Edit.php');
    }
 }
?>