<?php
 
 session_start();
 include('Connection.php');
 if(isset($_POST['personal']))
 {
    $id=$_SESSION['id'];
    $prenom=$_POST['prenom'];
    $nom=$_POST['nom'];
    $rank=$_POST['rank'];
    $field=$_POST['field'];
    $select= "select * from Enseignant where id='$id'";
    $sql = mysqli_query($conn,$select);
    $row = mysqli_fetch_assoc($sql);
    $res= $row['id'];
    $prevprenom=$row['prenom'];
    $prevnom=$row['nom'];
    if($res === $id)
    {
   
       $update = "update Enseignant set prénom='$prenom',nom='$nom',grade='$rank' where id='$id'";
       $sql2=mysqli_query($conn,$update);
if($sql2)
       { 
           /*Successful*/
           header('location:TeachView.php');
       }
       else
       {
           /*sorry your profile is not update*/
           header('location:Editens.php');
       }
    }
    else
    {
        /*sorry your id is not match*/
        header('location:Editens.php');
    }
 }
?>